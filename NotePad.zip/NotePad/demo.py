a= "sorabh"
b= "Rohit"

for i in b:
    if i not in a:
        print(b.replace(i,"+"))
        